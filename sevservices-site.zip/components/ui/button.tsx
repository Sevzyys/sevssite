import * as React from "react";
import clsx from "clsx";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  asChild?: boolean;
  variant?: "default" | "outline" | "secondary" | "ghost";
  className?: string;
  children?: React.ReactNode;
};

export function Button({ asChild, variant = "default", className, children, ...rest }: Props) {
  const base = "inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-medium transition shadow-sm";
  const variants: Record<string, string> = {
    default: "bg-slate-900 text-white hover:opacity-90",
    outline: "border border-slate-300 hover:bg-slate-50",
    secondary: "bg-slate-100 hover:bg-slate-200",
    ghost: "hover:bg-slate-100"
  };
  if (asChild) {
    return <button className={clsx(base, variants[variant], className)} {...rest}>{children}</button>;
  }
  return <button className={clsx(base, variants[variant], className)} {...rest}>{children}</button>;
}
