import * as React from "react";

export function Accordion({ children, className }: React.PropsWithChildren<{ className?: string, type?: "single", collapsible?: boolean }>) {
  return <div className={className}>{children}</div>;
}
export function AccordionItem({ children }: React.PropsWithChildren<{ value: string }>) {
  return <div className="border rounded-xl mb-2">{children}</div>;
}
export function AccordionTrigger({ children, className }: React.PropsWithChildren<{ className?: string }>) {
  const [open, setOpen] = React.useState(false);
  return (
    <button onClick={() => setOpen(!open)} className={`w-full text-left px-4 py-3 font-medium ${className || ""}`}>
      {children}
    </button>
  );
}
export function AccordionContent({ children, className }: React.PropsWithChildren<{ className?: string }>) {
  return <div className={`px-4 pb-4 text-sm ${className || ""}`}>{children}</div>;
}
